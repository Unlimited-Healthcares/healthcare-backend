import { DataSource } from 'typeorm';
export declare function seedEquipment(dataSource: DataSource): Promise<void>;
