"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EquipmentFileUploadService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const audit_service_1 = require("../../audit/audit.service");
const equipment_image_entity_1 = require("../entities/equipment-image.entity");
let EquipmentFileUploadService = class EquipmentFileUploadService {
    constructor(imageRepository, auditService) {
        this.imageRepository = imageRepository;
        this.auditService = auditService;
    }
    async uploadEquipmentFile(uploadDto, userId) {
        const publicUrl = `https://qnuzgpjkgyfdwxfkrscl.supabase.co/storage/v1/object/public/equipment-files/${uploadDto.filePath}`;
        const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(uploadDto.equipmentId);
        const validatedEquipmentId = isUuid ? uploadDto.equipmentId : null;
        const newImage = this.imageRepository.create({
            equipmentId: validatedEquipmentId,
            imageUrl: publicUrl,
            imageType: uploadDto.fileType,
            title: uploadDto.title,
            description: uploadDto.description,
            isPrimary: uploadDto.isPrimary || false,
            fileSize: uploadDto.fileSize,
            mimeType: uploadDto.mimeType,
            uploadedBy: userId,
        });
        try {
            const savedImage = await this.imageRepository.save(newImage);
            await this.auditService.logActivity(userId, 'equipment_file', 'UPLOAD_EQUIPMENT_FILE', `Equipment file uploaded for ${isUuid ? uploadDto.equipmentId : 'New Item (Draft)'}`, {
                equipmentId: isUuid ? uploadDto.equipmentId : 'DRAFT',
                fileName: uploadDto.fileName,
                fileType: uploadDto.fileType,
                imageId: savedImage.id
            });
            return this.mapToDto(savedImage);
        }
        catch (error) {
            console.error('❌ Failed to process equipment file upload:', error);
            throw error;
        }
    }
    async getEquipmentFiles(equipmentId, fileType) {
        const query = { equipmentId };
        if (fileType) {
            query.imageType = fileType;
        }
        const images = await this.imageRepository.find({
            where: query,
            order: { createdAt: 'DESC' }
        });
        return images.map(img => this.mapToDto(img));
    }
    async deleteEquipmentFile(fileId, userId) {
        const image = await this.imageRepository.findOne({ where: { id: fileId } });
        if (!image) {
            throw new common_1.NotFoundException('File not found');
        }
        await this.imageRepository.delete(fileId);
        await this.auditService.logActivity(userId, 'equipment_file', 'DELETE_EQUIPMENT_FILE', 'Equipment file deleted', { fileId });
    }
    async setPrimaryImage(fileId, equipmentId, userId) {
        await this.imageRepository.update({ equipmentId }, { isPrimary: false });
        await this.imageRepository.update(fileId, { isPrimary: true });
        const updatedImage = await this.imageRepository.findOne({ where: { id: fileId } });
        await this.auditService.logActivity(userId, 'equipment_file', 'SET_PRIMARY_EQUIPMENT_IMAGE', 'Primary equipment image set', { fileId, equipmentId });
        return this.mapToDto(updatedImage);
    }
    async getPresignedUrl(fileName, fileType, equipmentId) {
        const filePath = `equipment/${equipmentId}/${fileType}s/${fileName}`;
        return {
            url: 'https://qnuzgpjkgyfdwxfkrscl.supabase.co/storage/v1/object/sign/equipment-files',
            fields: {
                bucket: 'equipment-files',
                key: filePath,
                'Content-Type': 'image/jpeg',
            }
        };
    }
    mapToDto(image) {
        return {
            id: image.id,
            equipmentId: image.equipmentId,
            fileType: image.imageType,
            fileName: image.imageUrl.split('/').pop() || 'unknown',
            filePath: image.imageUrl.replace('https://qnuzgpjkgyfdwxfkrscl.supabase.co/storage/v1/object/public/equipment-files/', ''),
            fileSize: image.fileSize || 0,
            mimeType: image.mimeType || 'unknown',
            title: image.title,
            description: image.description,
            isPrimary: image.isPrimary,
            uploadedBy: image.uploadedBy || 'system',
            uploadedAt: image.createdAt?.toISOString() || new Date().toISOString(),
            publicUrl: image.imageUrl,
        };
    }
};
exports.EquipmentFileUploadService = EquipmentFileUploadService;
exports.EquipmentFileUploadService = EquipmentFileUploadService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(equipment_image_entity_1.EquipmentImage)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        audit_service_1.AuditService])
], EquipmentFileUploadService);
//# sourceMappingURL=equipment-file-upload.service.js.map