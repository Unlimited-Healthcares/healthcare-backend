import { MulterFile } from '../../types/express';
import { EquipmentFileUploadService } from '../services/equipment-file-upload.service';
export declare class EquipmentFileUploadController {
    private readonly equipmentFileUploadService;
    constructor(equipmentFileUploadService: EquipmentFileUploadService);
    getPresignedUrl(fileName: string, fileType: string, equipmentId: string): Promise<{
        url: string;
        fields: Record<string, string>;
    }>;
    uploadEquipmentFile(file: MulterFile, equipmentId: string, fileType: 'image' | 'document' | 'manual' | 'certificate', userId: string, title?: string, description?: string, isPrimary?: boolean): Promise<import("../services/equipment-file-upload.service").EquipmentFile>;
    getEquipmentFiles(equipmentId: string, fileType?: string): Promise<import("../services/equipment-file-upload.service").EquipmentFile[]>;
    deleteEquipmentFile(fileId: string, userId: string): Promise<void>;
    setPrimaryImage(fileId: string, equipmentId: string, userId: string): Promise<import("../services/equipment-file-upload.service").EquipmentFile>;
}
