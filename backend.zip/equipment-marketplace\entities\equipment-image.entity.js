"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EquipmentImage = void 0;
const typeorm_1 = require("typeorm");
const equipment_item_entity_1 = require("./equipment-item.entity");
let EquipmentImage = class EquipmentImage {
};
exports.EquipmentImage = EquipmentImage;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], EquipmentImage.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'equipment_id', nullable: true }),
    __metadata("design:type", String)
], EquipmentImage.prototype, "equipmentId", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'image_url', length: 500 }),
    __metadata("design:type", String)
], EquipmentImage.prototype, "imageUrl", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'image_type', length: 20, default: 'photo' }),
    __metadata("design:type", String)
], EquipmentImage.prototype, "imageType", void 0);
__decorate([
    (0, typeorm_1.Column)({ length: 200, nullable: true }),
    __metadata("design:type", String)
], EquipmentImage.prototype, "title", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", String)
], EquipmentImage.prototype, "description", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'is_primary', default: false }),
    __metadata("design:type", Boolean)
], EquipmentImage.prototype, "isPrimary", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'file_size', nullable: true }),
    __metadata("design:type", Number)
], EquipmentImage.prototype, "fileSize", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'mime_type', length: 100, nullable: true }),
    __metadata("design:type", String)
], EquipmentImage.prototype, "mimeType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'display_order', default: 0 }),
    __metadata("design:type", Number)
], EquipmentImage.prototype, "displayOrder", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'uploaded_by', nullable: true }),
    __metadata("design:type", String)
], EquipmentImage.prototype, "uploadedBy", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'created_at' }),
    __metadata("design:type", Date)
], EquipmentImage.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => equipment_item_entity_1.EquipmentItem, { onDelete: 'CASCADE' }),
    (0, typeorm_1.JoinColumn)({ name: 'equipment_id' }),
    __metadata("design:type", equipment_item_entity_1.EquipmentItem)
], EquipmentImage.prototype, "equipment", void 0);
exports.EquipmentImage = EquipmentImage = __decorate([
    (0, typeorm_1.Entity)('equipment_images')
], EquipmentImage);
//# sourceMappingURL=equipment-image.entity.js.map