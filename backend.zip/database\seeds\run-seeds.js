"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.runSeeds = void 0;
const datasource_1 = require("../../datasource");
const ambulance_seed_1 = require("./ambulance-seed");
const admin_seed_1 = require("./admin-seed");
const equipment_seed_1 = require("./equipment-seed");
async function runSeeds() {
    try {
        console.log('🌱 Starting database seeding...');
        if (!datasource_1.default.isInitialized) {
            await datasource_1.default.initialize();
        }
        console.log('✅ Database connection established');
        await (0, admin_seed_1.seedAdmin)(datasource_1.default);
        await (0, ambulance_seed_1.seedAmbulances)(datasource_1.default);
        await (0, equipment_seed_1.seedEquipment)(datasource_1.default);
        console.log('✅ Database seeding completed successfully');
    }
    catch (error) {
        console.error('❌ Error during database seeding:', error);
        process.exit(1);
    }
    finally {
        if (datasource_1.default.isInitialized) {
            await datasource_1.default.destroy();
        }
    }
}
exports.runSeeds = runSeeds;
if (require.main === module) {
    runSeeds();
}
//# sourceMappingURL=run-seeds.js.map