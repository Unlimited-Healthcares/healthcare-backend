"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EquipmentMarketplaceModule = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const equipment_category_entity_1 = require("./entities/equipment-category.entity");
const equipment_vendor_entity_1 = require("./entities/equipment-vendor.entity");
const equipment_item_entity_1 = require("./entities/equipment-item.entity");
const equipment_specification_entity_1 = require("./entities/equipment-specification.entity");
const equipment_image_entity_1 = require("./entities/equipment-image.entity");
const purchase_order_entity_1 = require("./entities/purchase-order.entity");
const shopping_cart_entity_1 = require("./entities/shopping-cart.entity");
const equipment_categories_service_1 = require("./services/equipment-categories.service");
const equipment_vendors_service_1 = require("./services/equipment-vendors.service");
const equipment_items_service_1 = require("./services/equipment-items.service");
const equipment_rental_service_1 = require("./services/equipment-rental.service");
const equipment_sales_service_1 = require("./services/equipment-sales.service");
const equipment_maintenance_service_1 = require("./services/equipment-maintenance.service");
const equipment_file_upload_service_1 = require("./services/equipment-file-upload.service");
const shopping_cart_service_1 = require("./services/shopping-cart.service");
const equipment_categories_controller_1 = require("./controllers/equipment-categories.controller");
const equipment_vendors_controller_1 = require("./controllers/equipment-vendors.controller");
const equipment_items_controller_1 = require("./controllers/equipment-items.controller");
const equipment_rental_controller_1 = require("./controllers/equipment-rental.controller");
const equipment_sales_controller_1 = require("./controllers/equipment-sales.controller");
const equipment_maintenance_controller_1 = require("./controllers/equipment-maintenance.controller");
const equipment_file_upload_controller_1 = require("./controllers/equipment-file-upload.controller");
const shopping_cart_controller_1 = require("./controllers/shopping-cart.controller");
const audit_module_1 = require("../audit/audit.module");
const integrations_module_1 = require("../integrations/integrations.module");
const wallets_module_1 = require("../wallets/wallets.module");
let EquipmentMarketplaceModule = class EquipmentMarketplaceModule {
};
exports.EquipmentMarketplaceModule = EquipmentMarketplaceModule;
exports.EquipmentMarketplaceModule = EquipmentMarketplaceModule = __decorate([
    (0, common_1.Module)({
        imports: [
            typeorm_1.TypeOrmModule.forFeature([
                equipment_category_entity_1.EquipmentCategory,
                equipment_vendor_entity_1.EquipmentVendor,
                equipment_item_entity_1.EquipmentItem,
                equipment_specification_entity_1.EquipmentSpecification,
                equipment_image_entity_1.EquipmentImage,
                purchase_order_entity_1.PurchaseOrder,
                purchase_order_entity_1.OrderItem,
                shopping_cart_entity_1.ShoppingCart,
                shopping_cart_entity_1.CartItem,
            ]),
            audit_module_1.AuditModule,
            integrations_module_1.IntegrationsModule,
            wallets_module_1.WalletsModule,
        ],
        controllers: [
            equipment_categories_controller_1.EquipmentCategoriesController,
            equipment_vendors_controller_1.EquipmentVendorsController,
            equipment_items_controller_1.EquipmentItemsController,
            equipment_rental_controller_1.EquipmentRentalController,
            equipment_sales_controller_1.EquipmentSalesController,
            equipment_maintenance_controller_1.EquipmentMaintenanceController,
            equipment_file_upload_controller_1.EquipmentFileUploadController,
            shopping_cart_controller_1.ShoppingCartController,
        ],
        providers: [
            equipment_categories_service_1.EquipmentCategoriesService,
            equipment_vendors_service_1.EquipmentVendorsService,
            equipment_items_service_1.EquipmentItemsService,
            equipment_rental_service_1.EquipmentRentalService,
            equipment_sales_service_1.EquipmentSalesService,
            equipment_maintenance_service_1.EquipmentMaintenanceService,
            equipment_file_upload_service_1.EquipmentFileUploadService,
            shopping_cart_service_1.ShoppingCartService,
        ],
        exports: [
            equipment_categories_service_1.EquipmentCategoriesService,
            equipment_vendors_service_1.EquipmentVendorsService,
            equipment_items_service_1.EquipmentItemsService,
            equipment_rental_service_1.EquipmentRentalService,
            equipment_sales_service_1.EquipmentSalesService,
            equipment_maintenance_service_1.EquipmentMaintenanceService,
            equipment_file_upload_service_1.EquipmentFileUploadService,
        ],
    })
], EquipmentMarketplaceModule);
//# sourceMappingURL=equipment-marketplace.module.js.map