declare function runSeeds(): Promise<void>;
export { runSeeds };
