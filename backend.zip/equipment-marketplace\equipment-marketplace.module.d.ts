export declare class EquipmentMarketplaceModule {
}
