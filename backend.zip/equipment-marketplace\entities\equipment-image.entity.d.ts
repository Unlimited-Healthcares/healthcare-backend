import { EquipmentItem } from './equipment-item.entity';
export declare class EquipmentImage {
    id: string;
    equipmentId: string;
    imageUrl: string;
    imageType: string;
    title: string;
    description: string;
    isPrimary: boolean;
    fileSize: number;
    mimeType: string;
    displayOrder: number;
    uploadedBy: string;
    createdAt: Date;
    equipment: EquipmentItem;
}
