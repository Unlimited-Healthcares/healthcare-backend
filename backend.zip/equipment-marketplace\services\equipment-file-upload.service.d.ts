import { Repository } from 'typeorm';
import { AuditService } from '../../audit/audit.service';
import { EquipmentImage } from '../entities/equipment-image.entity';
export interface UploadEquipmentFileDto {
    equipmentId: string;
    fileType: 'image' | 'document' | 'manual' | 'certificate';
    fileName: string;
    filePath: string;
    fileSize: number;
    mimeType: string;
    title?: string;
    description?: string;
    isPrimary?: boolean;
}
export interface EquipmentFile {
    id: string;
    equipmentId: string;
    fileType: string;
    fileName: string;
    filePath: string;
    fileSize: number;
    mimeType: string;
    title?: string;
    description?: string;
    isPrimary: boolean;
    uploadedBy: string;
    uploadedAt: string;
    publicUrl: string;
}
export declare class EquipmentFileUploadService {
    private readonly imageRepository;
    private readonly auditService;
    constructor(imageRepository: Repository<EquipmentImage>, auditService: AuditService);
    uploadEquipmentFile(uploadDto: UploadEquipmentFileDto, userId: string): Promise<EquipmentFile>;
    getEquipmentFiles(equipmentId: string, fileType?: string): Promise<EquipmentFile[]>;
    deleteEquipmentFile(fileId: string, userId: string): Promise<void>;
    setPrimaryImage(fileId: string, equipmentId: string, userId: string): Promise<EquipmentFile>;
    getPresignedUrl(fileName: string, fileType: string, equipmentId: string): Promise<{
        url: string;
        fields: Record<string, string>;
    }>;
    private mapToDto;
}
