"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.seedEquipment = void 0;
const equipment_category_entity_1 = require("../../equipment-marketplace/entities/equipment-category.entity");
const equipment_vendor_entity_1 = require("../../equipment-marketplace/entities/equipment-vendor.entity");
const equipment_item_entity_1 = require("../../equipment-marketplace/entities/equipment-item.entity");
const equipment_specification_entity_1 = require("../../equipment-marketplace/entities/equipment-specification.entity");
const equipment_image_entity_1 = require("../../equipment-marketplace/entities/equipment-image.entity");
const purchase_order_entity_1 = require("../../equipment-marketplace/entities/purchase-order.entity");
const shopping_cart_entity_1 = require("../../equipment-marketplace/entities/shopping-cart.entity");
const equipment_status_enum_1 = require("../../equipment-marketplace/enums/equipment-status.enum");
async function seedEquipment(dataSource) {
    const categoryRepo = dataSource.getRepository(equipment_category_entity_1.EquipmentCategory);
    const vendorRepo = dataSource.getRepository(equipment_vendor_entity_1.EquipmentVendor);
    const itemRepo = dataSource.getRepository(equipment_item_entity_1.EquipmentItem);
    const specRepo = dataSource.getRepository(equipment_specification_entity_1.EquipmentSpecification);
    const imageRepo = dataSource.getRepository(equipment_image_entity_1.EquipmentImage);
    const orderItemRepo = dataSource.getRepository(purchase_order_entity_1.OrderItem);
    const orderRepo = dataSource.getRepository(purchase_order_entity_1.PurchaseOrder);
    const cartItemRepo = dataSource.getRepository(shopping_cart_entity_1.CartItem);
    const cartRepo = dataSource.getRepository(shopping_cart_entity_1.ShoppingCart);
    console.log('🌱 Starting comprehensive equipment marketplace seed...');
    try {
        console.log('🧹 Deep clearing all marketplace data...');
        await cartItemRepo.delete({});
        await cartRepo.delete({});
        await orderItemRepo.delete({});
        await orderRepo.delete({});
        await specRepo.delete({});
        await imageRepo.delete({});
        await itemRepo.delete({});
        await categoryRepo.delete({});
        await vendorRepo.delete({});
        console.log('✅ Marketplace cleared');
    }
    catch (e) {
        console.warn(`⚠️ Warning during clear (might be expected if tables are empty): ${e.message}`);
    }
    const categoriesData = [
        { name: 'Diagnostic Imaging', code: 'DIAG', desc: 'MRI, CT, X-Ray and Ultrasound machines' },
        { name: 'Life Support', code: 'LIFE', desc: 'Ventilators, Defibrillators, and Anesthesia machines' },
        { name: 'Patient Monitoring', code: 'MONI', desc: 'ECG, Pulse Oximeters, and Vital Signs Monitors' },
        { name: 'Laboratory Equipment', code: 'LABS', desc: 'Analyzers, Centrifuges, and Microscopes' },
        { name: 'Surgical Instruments', code: 'SURG', desc: 'Electrosurgical units, Lasers, and Robotic systems' },
        { name: 'Consumer Health', code: 'CONS', desc: 'Blood pressure monitors, thermometers, and home health devices' },
        { name: 'Wound Care', code: 'WOUND', desc: 'Bandages, dressings, and wound treatment supplies' },
        { name: 'First Aid & Safety', code: 'SAFE', desc: 'First aid kits, emergency supplies, and safety gear' },
        { name: 'PPE', code: 'PPE', desc: 'Masks, gloves, and protective clothing' }
    ];
    const categories = {};
    for (const cat of categoriesData) {
        const category = categoryRepo.create({
            name: cat.name,
            categoryCode: cat.code,
            description: cat.desc,
            isActive: true,
        });
        const saved = await categoryRepo.save(category);
        categories[cat.code] = saved;
    }
    const vendorsData = [
        { name: 'Unlimited Healthcare Store', email: 'store@unlimitedhealthcare.com', phone: '+234-800-UHC-SHOP', desc: 'Official platform store' },
        { name: 'GE Healthcare Solutions', email: 'vending@gehealthcare.com', phone: '+1-800-GE-MED' },
        { name: 'Siemens Healthineers', email: 'sales@siemens-health.com', phone: '+49-9131-84-0' },
        { name: 'Philips Medical Systems', email: 'info@philips-medical.com', phone: '+31-20-59-77777' },
        { name: 'Medtronic Global', email: 'orders@medtronic.com', phone: '+1-763-514-4000' }
    ];
    const vendors = {};
    for (const ven of vendorsData) {
        const vendor = vendorRepo.create({
            companyName: ven.name,
            email: ven.email,
            phone: ven.phone,
            verificationStatus: equipment_status_enum_1.VerificationStatus.VERIFIED,
            isActive: true,
            ratingAverage: 4.8,
            totalRatings: 120,
            description: ven.desc || 'Quality medical technology provider'
        });
        const saved = await vendorRepo.save(vendor);
        vendors[ven.name] = saved;
    }
    const itemsData = [
        {
            name: 'Digital Blood Pressure Monitor',
            cat: 'CONS',
            ven: 'Unlimited Healthcare Store',
            price: 49.99,
            rent: 0,
            desc: 'Automatic upper arm BP monitor with memory for two users.',
            model: 'BP-202X',
            manufacturer: 'UHC Health',
            img: 'https://images.unsplash.com/photo-1631549916768-4119b295f7ef?auto=format&fit=crop&q=80&w=800',
            cond: equipment_status_enum_1.EquipmentCondition.NEW,
            stat: equipment_status_enum_1.AvailabilityStatus.AVAILABLE
        },
        {
            name: 'Infrared No-Contact Thermometer',
            cat: 'CONS',
            ven: 'Unlimited Healthcare Store',
            price: 34.50,
            rent: 0,
            desc: 'Instant 1-second temperature reading for medical and home use.',
            model: 'IR-TEMP-99',
            manufacturer: 'UHC Health',
            img: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&q=80&w=800',
            cond: equipment_status_enum_1.EquipmentCondition.NEW,
            stat: equipment_status_enum_1.AvailabilityStatus.RENTED
        },
        {
            name: 'Siemens Ultrasound Machine',
            cat: 'DIAG',
            ven: 'Siemens Healthineers',
            price: 12500,
            rent: 150,
            desc: 'High-resolution imaging for various diagnostic applications.',
            model: 'SIM-U-500',
            manufacturer: 'Siemens',
            img: 'https://images.unsplash.com/photo-1516549655169-df83a0774514?auto=format&fit=crop&q=80&w=800',
            cond: equipment_status_enum_1.EquipmentCondition.REFURBISHED,
            stat: equipment_status_enum_1.AvailabilityStatus.AVAILABLE
        },
        {
            name: 'GE Revolution CT Scanner',
            cat: 'DIAG',
            ven: 'GE Healthcare Solutions',
            price: 750000,
            rent: 2500,
            desc: 'Next-generation CT scanner with high-definition imaging.',
            model: 'REV-CT-2024',
            manufacturer: 'GE',
            img: 'https://images.unsplash.com/photo-1616391182219-e080b4d1043a?auto=format&fit=crop&q=80&w=800',
            cond: equipment_status_enum_1.EquipmentCondition.NEW,
            stat: equipment_status_enum_1.AvailabilityStatus.AVAILABLE
        },
        {
            name: 'Hamilton-G5 ICU Ventilator',
            cat: 'LIFE',
            ven: 'Medtronic Global',
            price: 45000,
            rent: 350,
            desc: 'Advanced mechanical ventilator for respiratory support.',
            model: 'HAM-G5',
            manufacturer: 'Hamilton Medical',
            img: 'https://images.unsplash.com/photo-1581093588401-fbb62a02f120?auto=format&fit=crop&q=80&w=800',
            cond: equipment_status_enum_1.EquipmentCondition.NEW,
            stat: equipment_status_enum_1.AvailabilityStatus.AVAILABLE
        },
        {
            name: 'Used Patient Bed',
            cat: 'LIFE',
            ven: 'Unlimited Healthcare Store',
            price: 850,
            rent: 25,
            desc: 'Well-maintained used hospital bed with complete adjustments.',
            model: 'BED-PRO-99',
            manufacturer: 'MediRest',
            img: 'https://images.unsplash.com/photo-1586773860418-d37222d8fce2?auto=format&fit=crop&q=80&w=800',
            cond: equipment_status_enum_1.EquipmentCondition.USED,
            stat: equipment_status_enum_1.AvailabilityStatus.AVAILABLE
        },
        {
            name: 'Binocular Lab Microscope',
            cat: 'LABS',
            ven: 'Philips Medical Systems',
            price: 1200,
            rent: 0,
            desc: 'High-precision lab microscope with dual illumination.',
            model: 'LAB-SCOPE-X',
            manufacturer: 'OpticMed',
            img: 'https://images.unsplash.com/photo-1579389083046-e3d905432a2e?auto=format&fit=crop&q=80&w=800',
            cond: equipment_status_enum_1.EquipmentCondition.EXCELLENT,
            stat: equipment_status_enum_1.AvailabilityStatus.MAINTENANCE
        },
        {
            name: 'Hematology Analyzer',
            cat: 'LABS',
            ven: 'Medtronic Global',
            price: 5500,
            rent: 0,
            desc: 'Automated 3-part differential blood cell counter.',
            model: 'HEM-300',
            manufacturer: 'Medtronic',
            img: 'https://images.unsplash.com/photo-1579165466541-7183b6f9055d?auto=format&fit=crop&q=80&w=800',
            cond: equipment_status_enum_1.EquipmentCondition.GOOD,
            stat: equipment_status_enum_1.AvailabilityStatus.AVAILABLE
        },
        {
            name: 'ECG Monitor System',
            cat: 'MONI',
            ven: 'Medtronic Global',
            price: 4500,
            rent: 0,
            desc: 'Portable multiparameter patient monitor.',
            model: 'ECG-PRO',
            manufacturer: 'Medtronic',
            img: 'https://images.unsplash.com/photo-1551076805-e1869033e561?auto=format&fit=crop&q=80&w=800',
            cond: equipment_status_enum_1.EquipmentCondition.FAIR,
            stat: equipment_status_enum_1.AvailabilityStatus.OUT_OF_ORDER
        },
        {
            name: 'Electrosurgical Unit',
            cat: 'SURG',
            ven: 'GE Healthcare Solutions',
            price: 8500,
            rent: 200,
            desc: 'Versatile surgical unit for advanced medical procedures.',
            model: 'SURG-E-200',
            manufacturer: 'GE',
            img: 'https://images.unsplash.com/photo-1581093588401-fbb62a02f120?auto=format&fit=crop&q=80&w=800',
            cond: equipment_status_enum_1.EquipmentCondition.GOOD,
            stat: equipment_status_enum_1.AvailabilityStatus.AVAILABLE
        },
        {
            name: 'Medical Isolation Gowns (100 Pack)',
            cat: 'PPE',
            ven: 'Unlimited Healthcare Store',
            price: 120.00,
            rent: 0,
            desc: 'Disposable fluid-resistant protection gowns.',
            model: 'GOWN-MED-1',
            manufacturer: 'SafetyFirst',
            img: 'https://images.unsplash.com/photo-1584622781564-1d987f7333c1?auto=format&fit=crop&q=80&w=800',
            cond: equipment_status_enum_1.EquipmentCondition.NEW,
            stat: equipment_status_enum_1.AvailabilityStatus.AVAILABLE
        },
        {
            name: 'Industrial First Aid Kit',
            cat: 'SAFE',
            ven: 'Unlimited Healthcare Store',
            price: 145.00,
            rent: 0,
            desc: 'Wall-mountable compliance kit for workplaces.',
            model: 'SAFE-IND-01',
            manufacturer: 'SafeHealth',
            img: 'https://images.unsplash.com/photo-1603398938378-e54eab446f21?auto=format&fit=crop&q=80&w=800',
            cond: equipment_status_enum_1.EquipmentCondition.NEW,
            stat: equipment_status_enum_1.AvailabilityStatus.AVAILABLE
        },
        {
            name: 'Wound Care Supply Bundle',
            cat: 'WOUND',
            ven: 'Unlimited Healthcare Store',
            price: 65.00,
            rent: 0,
            desc: 'All-inclusive sterile dressings and bandage set.',
            model: 'WOUND-KIT',
            manufacturer: 'UHC Health',
            img: 'https://images.unsplash.com/photo-1631549916768-4119b295f7ef?auto=format&fit=crop&q=80&w=800',
            cond: equipment_status_enum_1.EquipmentCondition.NEW,
            stat: equipment_status_enum_1.AvailabilityStatus.AVAILABLE
        }
    ];
    for (const item of itemsData) {
        const newItem = itemRepo.create({
            name: item.name,
            description: item.desc,
            categoryId: categories[item.cat].id,
            vendorId: vendors[item.ven].id,
            salePrice: item.price,
            rentalPriceDaily: item.rent > 0 ? item.rent : null,
            isForSale: true,
            isRentable: item.rent > 0,
            availabilityStatus: item.stat,
            condition: item.cond,
            modelNumber: item.model,
            manufacturer: item.manufacturer,
            images: [item.img],
            isActive: true
        });
        await itemRepo.save(newItem);
    }
    console.log('✅ Equipment marketplace seeded successfully');
}
exports.seedEquipment = seedEquipment;
//# sourceMappingURL=equipment-seed.js.map